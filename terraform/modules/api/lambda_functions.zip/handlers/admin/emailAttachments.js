var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/admin/emailAttachments.js
var emailAttachments_exports = {};
__export(emailAttachments_exports, {
  deleteAttachment: () => deleteAttachment,
  fetchAttachmentContent: () => fetchAttachmentContent,
  getDownloadUrl: () => getDownloadUrl,
  getPresignedUrl: () => getPresignedUrl,
  uploadAttachment: () => uploadAttachment
});
module.exports = __toCommonJS(emailAttachments_exports);
var import_client_s3 = require("@aws-sdk/client-s3");
var import_s3_request_presigner = require("@aws-sdk/s3-request-presigner");

// node_modules/uuid/dist/esm-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// node_modules/uuid/dist/esm-node/rng.js
var import_node_crypto = __toESM(require("node:crypto"));
var rnds8Pool = new Uint8Array(256);
var poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    import_node_crypto.default.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

// node_modules/uuid/dist/esm-node/native.js
var import_node_crypto2 = __toESM(require("node:crypto"));
var native_default = {
  randomUUID: import_node_crypto2.default.randomUUID
};

// node_modules/uuid/dist/esm-node/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// src/utils/response.js
var ALLOWED_ORIGINS = [
  "https://philocom.co",
  "https://www.philocom.co",
  "http://localhost:5173",
  "http://localhost:3000"
];
var getAllowedOrigin = (requestOrigin) => {
  if (requestOrigin && ALLOWED_ORIGINS.includes(requestOrigin)) {
    return requestOrigin;
  }
  return process.env.CORS_ORIGIN || "https://philocom.co";
};
var corsHeaders = (origin = "*") => ({
  "Access-Control-Allow-Origin": origin,
  "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Credentials": "true",
  "Content-Type": "application/json"
});
var successResponse = (data, statusCode = 200, event = null) => {
  const origin = event?.headers?.origin || event?.headers?.Origin;
  return {
    statusCode,
    headers: corsHeaders(getAllowedOrigin(origin)),
    body: JSON.stringify({
      success: true,
      data,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
};
var errorResponse = (message, statusCode = 400, error = null, event = null) => {
  const origin = event?.headers?.origin || event?.headers?.Origin;
  return {
    statusCode,
    headers: corsHeaders(getAllowedOrigin(origin)),
    body: JSON.stringify({
      success: false,
      error: message,
      details: error?.message || null,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
};
var validationErrorResponse = (errors, event = null) => {
  const origin = event?.headers?.origin || event?.headers?.Origin;
  return {
    statusCode: 422,
    headers: corsHeaders(getAllowedOrigin(origin)),
    body: JSON.stringify({
      success: false,
      error: "Validation failed",
      errors,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
};

// src/handlers/admin/emailAttachments.js
var BUCKET_NAME = process.env.IMAGES_BUCKET_NAME;
var REGION = process.env.AWS_REGION || "eu-central-1";
var s3Client = new import_client_s3.S3Client({ region: REGION });
var ALLOWED_TYPES = {
  // Documents
  "application/pdf": { ext: "pdf", maxSize: 10 },
  "application/msword": { ext: "doc", maxSize: 10 },
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": { ext: "docx", maxSize: 10 },
  "application/vnd.ms-excel": { ext: "xls", maxSize: 10 },
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": { ext: "xlsx", maxSize: 10 },
  "application/vnd.ms-powerpoint": { ext: "ppt", maxSize: 10 },
  "application/vnd.openxmlformats-officedocument.presentationml.presentation": { ext: "pptx", maxSize: 10 },
  "text/plain": { ext: "txt", maxSize: 5 },
  "text/csv": { ext: "csv", maxSize: 10 },
  // Images
  "image/jpeg": { ext: "jpg", maxSize: 5 },
  "image/png": { ext: "png", maxSize: 5 },
  "image/gif": { ext: "gif", maxSize: 5 },
  "image/webp": { ext: "webp", maxSize: 5 },
  // Archives
  "application/zip": { ext: "zip", maxSize: 25 },
  "application/x-zip-compressed": { ext: "zip", maxSize: 25 }
};
var MAX_TOTAL_SIZE = 25 * 1024 * 1024;
var validateFile = (contentType, size) => {
  const fileConfig = ALLOWED_TYPES[contentType];
  if (!fileConfig) {
    return {
      valid: false,
      error: `File type not allowed. Supported types: PDF, DOCX, XLSX, PPTX, images, CSV, TXT, ZIP`
    };
  }
  const maxSize = fileConfig.maxSize * 1024 * 1024;
  if (size > maxSize) {
    return {
      valid: false,
      error: `File too large. Maximum size for ${contentType}: ${fileConfig.maxSize}MB`
    };
  }
  return { valid: true, fileConfig };
};
var sanitizeFilename = (filename) => {
  let sanitized = filename.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
  if (sanitized.length > 100) {
    const ext = sanitized.split(".").pop();
    const name = sanitized.substring(0, 95 - ext.length);
    sanitized = `${name}.${ext}`;
  }
  return sanitized;
};
var getPresignedUrl = async (event) => {
  try {
    const data = JSON.parse(event.body);
    const errors = [];
    if (!data.filename) {
      errors.push("Filename is required");
    }
    if (!data.contentType) {
      errors.push("Content type is required");
    }
    if (!data.size || data.size <= 0) {
      errors.push("Valid file size is required");
    }
    if (errors.length > 0) {
      return validationErrorResponse(errors, event);
    }
    const validation = validateFile(data.contentType, data.size);
    if (!validation.valid) {
      return validationErrorResponse([validation.error], event);
    }
    const sanitizedFilename = sanitizeFilename(data.filename);
    const emailId = data.emailId || "draft";
    const uniqueId = v4_default();
    const ext = validation.fileConfig.ext;
    const key = `emails/attachments/${emailId}/${uniqueId}_${sanitizedFilename}`;
    const command = new import_client_s3.PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      ContentType: data.contentType,
      ContentLength: data.size,
      Metadata: {
        "original-filename": sanitizedFilename,
        "uploaded-by": "email-compose"
      }
    });
    const presignedUrl = await (0, import_s3_request_presigner.getSignedUrl)(s3Client, command, { expiresIn: 900 });
    const publicUrl = `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${key}`;
    return successResponse({
      presignedUrl,
      publicUrl,
      key,
      expiresIn: 900,
      metadata: {
        id: uniqueId,
        filename: sanitizedFilename,
        contentType: data.contentType,
        size: data.size
      }
    }, 200, event);
  } catch (error) {
    console.error("Error generating presigned URL for attachment:", error);
    return errorResponse("Failed to generate upload URL", 500, error, event);
  }
};
var uploadAttachment = async (event) => {
  try {
    const data = JSON.parse(event.body);
    const errors = [];
    if (!data.file) {
      errors.push("File data is required");
    }
    if (!data.filename) {
      errors.push("Filename is required");
    }
    if (!data.contentType) {
      errors.push("Content type is required");
    }
    if (errors.length > 0) {
      return validationErrorResponse(errors, event);
    }
    const base64Data = data.file.replace(/^data:[^;]+;base64,/, "");
    const buffer = Buffer.from(base64Data, "base64");
    const validation = validateFile(data.contentType, buffer.length);
    if (!validation.valid) {
      return validationErrorResponse([validation.error], event);
    }
    const sanitizedFilename = sanitizeFilename(data.filename);
    const emailId = data.emailId || "draft";
    const uniqueId = v4_default();
    const key = `emails/attachments/${emailId}/${uniqueId}_${sanitizedFilename}`;
    const command = new import_client_s3.PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      Body: buffer,
      ContentType: data.contentType,
      Metadata: {
        "original-filename": sanitizedFilename,
        "uploaded-by": "email-compose"
      }
    });
    await s3Client.send(command);
    const publicUrl = `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${key}`;
    return successResponse({
      message: "Attachment uploaded successfully",
      url: publicUrl,
      key,
      metadata: {
        id: uniqueId,
        filename: sanitizedFilename,
        contentType: data.contentType,
        size: buffer.length
      }
    }, 201, event);
  } catch (error) {
    console.error("Error uploading attachment:", error);
    return errorResponse("Failed to upload attachment", 500, error, event);
  }
};
var getDownloadUrl = async (event) => {
  try {
    const key = decodeURIComponent(event.pathParameters?.key || "");
    if (!key) {
      return validationErrorResponse(["Attachment key is required"], event);
    }
    if (!key.startsWith("emails/attachments/")) {
      return errorResponse("Invalid attachment key", 400, null, event);
    }
    const command = new import_client_s3.GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key
    });
    const downloadUrl = await (0, import_s3_request_presigner.getSignedUrl)(s3Client, command, { expiresIn: 3600 });
    const filename = key.split("/").pop().replace(/^[^_]+_/, "");
    return successResponse({
      downloadUrl,
      filename,
      expiresIn: 3600
    }, 200, event);
  } catch (error) {
    console.error("Error generating download URL:", error);
    return errorResponse("Failed to generate download URL", 500, error, event);
  }
};
var deleteAttachment = async (event) => {
  try {
    const key = decodeURIComponent(event.pathParameters?.key || "");
    if (!key) {
      return validationErrorResponse(["Attachment key is required"], event);
    }
    if (!key.startsWith("emails/attachments/")) {
      return errorResponse("Invalid attachment key", 400, null, event);
    }
    const command = new import_client_s3.DeleteObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key
    });
    await s3Client.send(command);
    return successResponse({
      message: "Attachment deleted successfully",
      key
    }, 200, event);
  } catch (error) {
    console.error("Error deleting attachment:", error);
    return errorResponse("Failed to delete attachment", 500, error, event);
  }
};
var fetchAttachmentContent = async (key) => {
  try {
    const command = new import_client_s3.GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key
    });
    const response = await s3Client.send(command);
    const chunks = [];
    for await (const chunk of response.Body) {
      chunks.push(chunk);
    }
    const buffer = Buffer.concat(chunks);
    return {
      buffer,
      contentType: response.ContentType,
      size: response.ContentLength,
      filename: response.Metadata?.["original-filename"] || key.split("/").pop()
    };
  } catch (error) {
    console.error("Error fetching attachment from S3:", error);
    throw new Error(`Failed to fetch attachment: ${error.message}`);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  deleteAttachment,
  fetchAttachmentContent,
  getDownloadUrl,
  getPresignedUrl,
  uploadAttachment
});
